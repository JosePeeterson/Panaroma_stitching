function [conv_img] = convolve(gray_img, kernel, ker_type, pad_x, pad_y)
% Apply convolution to the grayscale image

% add x and y padding to orignial gray_image on the left and right, top and
% bottom
gray_img = cat(2,zeros(size(gray_img,1),pad_x),gray_img,zeros(size(gray_img,1),pad_x));
gray_img = cat(1,zeros(pad_y,size(gray_img,2)),gray_img,zeros(pad_y,size(gray_img,2)));

switch ker_type
    case {'sobel', 'gaussian'}
        for i = pad_x + 1 : size(gray_img,1) - pad_y
            for j = pad_y + 1 : size(gray_img,2) - pad_x
                img_window = gray_img(i-pad_y:i+pad_y,j-pad_x:j+pad_x);
                conv_img(i-pad_x,j-pad_y) = uint8(sum(sum(double(img_window) .* kernel)));
            end            
        end    
    otherwise
        for i = 1:size(gray_img,1) - (pad_y*2)
            for j = 1:size(gray_img,2) - (pad_x*2)
                img_window = gray_img(i:i + pad_y,j:j+pad_x);
                conv_img(i,j) = uint8(sum(sum(double(img_window) .* kernel)));
            end
        end
               
end
 

end

