clc;
clear;
close all;

% load image and convert to grayscale
image = imread('img3.jpg');
if size(size(image),2) == 3
    gray_img = rgb2gray(image);
else
    gray_img = image;
end

%% SET PARAMETERS HERE

kernel_size = 16; % set the scale of kernel/masks here
ker_type = 'haar5'; % type of kernel, sobel, gaussian, haar1, haar2, haar3, haar4, haar5
sigma = 5; % for gaussian kernel

%% 
% select convolution operator 
switch ker_type
    case 'sobel'
        kernel = sobel(kernel_size);
    case 'gaussian'
        kernel = gaussian(kernel_size,sigma);
    otherwise
        kernel = Haar_masks(kernel_size,ker_type);
end


% perform convolution
pad_y = floor(kernel_size/2);
pad_x = pad_y ;
switch ker_type 
    case 'sobel'
        conv_x = convolve(gray_img, kernel{1,1}, ker_type, pad_x, pad_y);
        conv_y = convolve(gray_img, kernel{1,2}, ker_type, pad_x, pad_y);
        conv_img = conv_x + conv_y;
        
    case 'gaussian'
        conv_gauss = convolve(gray_img, kernel, ker_type, pad_x, pad_y);
    case {'haar1', 'haar2','haar3', 'haar4', 'haar5'}
        pad_x = size(kernel,2)-1;
        pad_y = size(kernel,1)-1;
        conv_haar = convolve(gray_img, kernel, ker_type, pad_x,pad_y);
end

% display results
switch ker_type 
    case 'sobel'
        figure; imshow(gray_img); title('Original image')
        figure; imshow(conv_x); title('After Convolving with Gx Sobel kernel');
        figure; imshow(conv_y); title('After Convolving with Gy Sobel kernel');
        figure; imshow(conv_img); title('After Convolving with sobel')
    case 'gaussian'
        figure; imshow(gray_img); title('Original image')
        figure; imshow(conv_gauss); title('After Convolving with gaussian')
    case {'haar1', 'haar2','haar3', 'haar4', 'haar5'}
        figure; imshow(gray_img); title('Original image')
        figure; imshow(conv_haar); title(['After Convolving with ', ker_type,' kernel'])
end


