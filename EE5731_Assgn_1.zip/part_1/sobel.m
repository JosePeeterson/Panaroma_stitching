function [kernel] = sobel(scale)
% Input = scale of kernel
% Output = kernel, the Gx and Gy matrices

scl = round(scale);

if (mod(scl,2) == 0)
    scl = scl + 1;
end
    
Gy = zeros(scl);
center = ceil(scl/2);

for x = center+1:scl
    for y = center:scl
        x1 = x - center;
        y1 = y - center;
        Gy(x,y) = x1 / (x1*x1 + y1*y1);        
    end
end

Gy(center+1:scl,1:center-1) = flip(Gy(center+1:scl,center+1:scl),2);
Gy(1:center-1,1:scl) = -flip(Gy(center+1:scl,1:scl));
Gx = rot90(Gy);

kernel = {Gx,Gy};

end

