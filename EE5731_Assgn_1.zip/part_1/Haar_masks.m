function [mask] = Haar_masks(scale,ker_type)
% Input = kernel size, Haar type
% Ouput = Haar type matrix of kernel size

switch ker_type
    case 'haar1'
        %vertical edge
        mask = ones(scale,2*scale);
        mask(:,1:scale)= -mask(:,1:scale);
    case 'haar2'
        %Horizontal edge
        mask = ones(scale,2*scale)';
        mask(1:scale,:) = -mask(1:scale,:)
    case 'haar3'
        %Vertical line
        mask = ones(scale,3*scale);
        mask(:,scale+1:2*scale)= -mask(:,scale+1:2*scale); 
    case 'haar4'
        %Horizontal line
        mask = ones(scale,3*scale)';
        mask(scale+1:2*scale,:)= -mask(scale+1:2*scale,:);  
    case 'haar5'
        %vertical corner
        mask = ones(scale,2*scale);
        mask(:,1:scale)= -mask(:,1:scale);
        mask = cat(1,mask,flip(mask,2));

end

