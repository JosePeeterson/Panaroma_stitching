function [Gaus_ker] = gaussian(scale,sigma)
% Input = size of kernel,standard deviation, sigma of kernel
% Output = kernel matrix with gaussian values

scl = round(scale);

if (mod(scl,2) == 0)
    scl = scl + 1;
end

Gaus_ker = zeros(scl);
center = ceil(scl/2);


for i = center:scl
    for j = center:i
        i1 = i - center;
        j1 = j - center;
        Gaus_ker(i,j) = (1 / (2*pi*(sigma^2)) ) * exp(-(i1^2+j1^2) / (2*(sigma^2)));
        Gaus_ker(j,i) = Gaus_ker(i,j);
    end
end

Gaus_ker(center:scl,1:center-1) = flip(Gaus_ker(center:scl,center+1:scl),2);
Gaus_ker(1:center-1,1:scl) = flip(Gaus_ker(center+1:scl,1:scl));
Gaus_ker = Gaus_ker/sum(sum(Gaus_ker))

end

